namespace ExamApi.Models;

public class Question
{
    public int Id { get; set; }
    public int ExamId { get; set; }
    public string Text { get; set; } = string.Empty;
    public string Type { get; set; } = "multiple"; // multiple, truefalse, open
    public string? OptionsJson { get; set; } // Guardar opciones como JSON
    public string? Answer { get; set; }

    public Exam? Exam { get; set; }
}
